vol_seq.txt contains pairs of MGS TES data volume numbers that should be read by the re-calibration setup program. 
Re-calibration setup is done using data covering a range of data volumes (usually 6). Sequential pairs of data volumes
overlap by one volume to provide smooth transition between fitted calibration functions calculated using these volumes.
Sometimes the range of volumes is smaller (e.g. 4) or larger (e.g. 6) - this is due to the presence of 'breaks' in the 
IRF behavior and is in attempt to optimize the use of data putting the 'break' at the start or end of long stretch of data 
(and thus using more data for fitting to Ti, and reducing the number of intervals used for fitting).